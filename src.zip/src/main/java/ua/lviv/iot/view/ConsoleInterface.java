package ua.lviv.iot.view;

import lombok.Getter;
import ua.lviv.iot.controller.ArtistController;
import ua.lviv.iot.controller.GenreController;

import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class ConsoleInterface {
  @Getter
  private static final ConsoleInterface INSTANCE = new ConsoleInterface();
  private ArtistController artistController = ArtistController.getINSTANCE();
  private GenreController genreController = GenreController.getINSTANCE();
  private Map<String, String> menu;
  private Map<String, Printable> methodsMenu;
  private Scanner input = new Scanner(System.in, "UTF-8");

  private ConsoleInterface() {
    menu = new LinkedHashMap<String, String>();
    methodsMenu = new LinkedHashMap<String, Printable>();

    menu.put("A", "  A - select all tables");

    menu.put("1", "  1 - Table: Artist");
    menu.put("11", "  11 - Create Artist");
    menu.put("12", "  12 - Update Artist");
    menu.put("13", "  13 - Delete from Artist");
    menu.put("14", "  14 - Select all from Artist");
    menu.put("15", "  15 - Select by ID from Artist");

    menu.put("2", "  2 - Table: Genre");
    menu.put("21", "  21 - Create Genre");
    menu.put("22", "  22 - Update Genre");
    menu.put("23", "  23 - Delete from Genre");
    menu.put("24", "  24 - Select all from Genre");
    menu.put("25", "  25 - Select by ID from Genre");
//
//    menu.put("3", "  3 - Table: MusicVideo");
//    menu.put("31", "  31 - Create MusicVideo");
//    menu.put("32", "  32 - Update MusicVideo");
//    menu.put("33", "  33 - Delete from MusicVideo");
//    menu.put("34", "  34 - Select all from MusicVideo");
//    menu.put("35", "  35 - Select by ID from MusicVideo");

    menu.put("Q", "  Q - exit");

    methodsMenu.put("11", artistController::createArtist);
    methodsMenu.put("12", artistController::updateArtist);
    methodsMenu.put("13", artistController::deleteArtist);
    methodsMenu.put("14", artistController::selectAllFromArtist);
    methodsMenu.put("15", artistController::selectFromArtistById);

    methodsMenu.put("21", genreController::createGenre);
    methodsMenu.put("22", genreController::updateGenre);
    methodsMenu.put("23", genreController::deleteGenre);
    methodsMenu.put("24", genreController::selectAllFromGenre);
    methodsMenu.put("25", genreController::selectFromGenreById);
//
//    methodsMenu.put("31", musicVideoController::createMusicVideo);
//    methodsMenu.put("32", musicVideoController::updateMusicVideo);
//    methodsMenu.put("33", musicVideoController::deleteMusicVideo);
//    methodsMenu.put("34", musicVideoController::selectAllFromMusicVideo);
//    methodsMenu.put("35", musicVideoController::selectFromMusicVideoById);

    methodsMenu.put("Q", this::exitOutput);
  }

  private void exitOutput() {
    System.out.println("Exiting program....");
  }

  private void outputMenu() {
    System.out.println("\nMENU:");
    for (String key : menu.keySet()) {
      if (key.length() == 1) {
        System.out.println(menu.get(key));
      }
    }
  }

  private void outputSubMenu(String subMenuKey) {
    System.out.println("\nSUB_MENU:");
    for (String key : menu.keySet()) {
      if (key.length() != 1 && key.substring(0, 1).equals(subMenuKey)) {
        System.out.println(menu.get(key));
      }
    }
  }

  public void show() {
    String menuKey;
    do {
      outputMenu();
      System.out.println("Please, select menu point.");
      menuKey = input.nextLine().toUpperCase();

      if (menuKey.matches("^\\d")) {
        outputSubMenu(menuKey);
        System.out.println("Please, select menu point.");
        menuKey = input.nextLine().toUpperCase();

      }

      try {
        methodsMenu.get(menuKey).print();
      } catch (SQLException exception) {
        exception.printStackTrace();
      }
    } while (!menuKey.equals("Q"));
  }
}
