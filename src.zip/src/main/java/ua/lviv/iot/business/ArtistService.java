package ua.lviv.iot.business;

import ua.lviv.iot.model.Artist;

public interface ArtistService extends GeneralService<Artist, Integer> {
}
