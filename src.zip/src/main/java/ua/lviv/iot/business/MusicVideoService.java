package ua.lviv.iot.business;

import ua.lviv.iot.model.MusicVideo;

public interface MusicVideoService extends GeneralService<MusicVideo, Integer> {
}
