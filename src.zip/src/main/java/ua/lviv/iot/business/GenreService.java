package ua.lviv.iot.business;

import ua.lviv.iot.model.Genre;

public interface GenreService extends GeneralService<Genre, Integer> {
}
