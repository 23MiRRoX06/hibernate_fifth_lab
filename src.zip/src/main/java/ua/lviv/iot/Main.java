package ua.lviv.iot;


import ua.lviv.iot.view.ConsoleInterface;

public class Main {

  public static void main(final String[] args) {
    ConsoleInterface.getINSTANCE().show();
  }
}