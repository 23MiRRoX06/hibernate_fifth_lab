package ua.lviv.iot.data_access;

import ua.lviv.iot.model.MusicVideo;

public interface MusicVideoDao extends GeneralDao<MusicVideo, Integer>{
}
