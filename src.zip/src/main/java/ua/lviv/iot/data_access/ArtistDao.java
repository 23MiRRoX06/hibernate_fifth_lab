package ua.lviv.iot.data_access;

import ua.lviv.iot.model.Artist;

public interface ArtistDao extends GeneralDao<Artist, Integer> {
}
