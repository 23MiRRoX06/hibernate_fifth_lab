package ua.lviv.iot.data_access;

import ua.lviv.iot.model.Genre;

public interface GenreDao extends GeneralDao<Genre, Integer>{
}
